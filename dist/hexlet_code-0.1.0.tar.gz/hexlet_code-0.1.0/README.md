### Hexlet tests and linter status:
[![Actions Status](https://github.com/Manreed/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Manreed/python-project-49/actions)

<a href="https://codeclimate.com/github/Manreed/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/ea84a98a6d9efd4ea296/maintainability" /></a>

brain-even:
https://asciinema.org/a/AlfnEm3NwaLRr8cnmRP7KoT9V


brain-calc:
https://asciinema.org/a/04weF0xOyVkYKf5z08vlL1c57


brain-gcd:
https://asciinema.org/a/O0ANNl6KJRMTuQEzfvBqNWPSO


brain-progression:
https://asciinema.org/a/EnCtCmRpQHw6HzqzSmORqdje7
